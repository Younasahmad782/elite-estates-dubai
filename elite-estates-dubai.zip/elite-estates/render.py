import sys
from playwright.sync_api import sync_playwright

HTML = "file:///home/hatch/workspace/elite-estates/index.html"
OUT = sys.argv[1] if len(sys.argv) > 1 else "/home/hatch/workspace/elite-estates/site.pdf"

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/home/hatch/.cache/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell")
    pg = b.new_page()
    pg.goto(HTML, wait_until="networkidle")
    pg.wait_for_timeout(1200)
    pg.pdf(path=OUT, width="210mm", height="297mm", print_background=True,
           prefer_css_page_size=False, margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
    b.close()
print("PDF written:", OUT)
